import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-trip-modal',
  templateUrl: './view-trip-modal.component.html',
  styleUrls: ['./view-trip-modal.component.scss'],
})
export class ViewTripModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
